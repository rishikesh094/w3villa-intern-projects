import CrudUI from "./pages/CrudUI"

function App() {
  
  return (
    <>
    <CrudUI/>
    </>
  )
}

export default App
